using NumbersToWords.Lib;
using System;
using Xunit;

namespace NumbersToWords.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void ShouldReturnZero()
        {
            int number = 0;
            string expected = "zero";

            string result = NumberToWordsConvertor.Convert(number);

            Assert.Equal(expected, result);
        }

        [Fact]
        public void ShouldReturnOne()
        {
            int number = 1;
            string expected = "one";

            string result = NumberToWordsConvertor.Convert(number);

            Assert.Equal(expected, result);
        }

        [Fact]
        public void ShouldReturnTen()
        {
            int number = 10;
            string expected = "ten";

            string result = NumberToWordsConvertor.Convert(number);

            Assert.Equal(expected, result);
        }

        [Fact]
        public void ShouldReturn19()
        {
            int number = 19;
            string expected = "nineteen";

            string result = NumberToWordsConvertor.Convert(number);

            Assert.Equal(expected, result);
        }
    }
}
