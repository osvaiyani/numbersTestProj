using NumbersToWords.Lib;
using System;
using Xunit;

namespace NumbersToWords.Tests
{
    public class UnitTest3
    {
        [Fact]
        public void ShouldReturn_three_hundred()
        {
            int number = 300;
            string expected = "three hundred";

            string result = NumberToWordsConvertor.GetTextForNumberGroup(number);

            Assert.Equal(result, expected);            
        }

        [Fact]
        public void ShouldReturn_three_hundred_and_fifteen()
        {
            int number = 315;
            string expected = "three hundred and fifteen";

            string result = NumberToWordsConvertor.GetTextForNumberGroup(number);

            Assert.Equal(result, expected);
        }

        [Fact]
        public void ShouldReturn_nine_hundred_and_ninetynine()
        {
            int number = 999;
            string expected = "nine hundred and ninety nine";

            string result = NumberToWordsConvertor.GetTextForNumberGroup(number);

            Assert.Equal(result, expected);
        }
    }
}
