using NumbersToWords.Lib;
using System;
using Xunit;

namespace NumbersToWords.Tests
{
    public class UnitTest2
    {
        [Fact]
        public void ShouldReturn100InGroup1()
        {
            int number = 100;
            int group1 = 100;            

            int[] result = NumberToWordsConvertor.GetNumberGroups(number);

            Assert.Equal(group1, result[0]);            
        }

        [Fact]
        public void ShouldReturn2InGroup2and101InGroup1()
        {
            int number = 2101;

            int group1 = 101;
            int group2 = 2;           

            int[] result = NumberToWordsConvertor.GetNumberGroups(number);

            Assert.Equal(group1, result[0]);
            Assert.Equal(group2, result[1]);
        }
    }
}
