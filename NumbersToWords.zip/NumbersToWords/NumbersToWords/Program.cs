﻿using NumbersToWords.Lib;
using System;

namespace NumbersToWords
{
    class Program
    {
        static void Main(string[] args)
        {
            // TODO expand beyond 999

            int number = 999;

            string result = NumberToWordsConvertor.Convert(number);

            Console.WriteLine(result);

            Console.ReadLine();
        }
    }
}
