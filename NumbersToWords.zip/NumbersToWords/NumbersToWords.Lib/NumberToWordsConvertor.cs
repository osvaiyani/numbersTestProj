﻿using System.Collections.Generic;

namespace NumbersToWords.Lib
{
    public static class NumberToWordsConvertor
    {
        #region Private Variables               

        private static List<string> zeroTo19 = new List<string> { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
        private static List<string> twentyTo100 = new List<string> { "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety", "hundred" };
        private static List<string> bigNumbers = new List<string> { "thousand", "million", "billion" };

        private const string AND = "and";

        #endregion
        
        #region Public Methods
        public static string Convert(int numberToConvert)
        {
            if (numberToConvert == 0)
                return zeroTo19[0];

            int[] numberGroups = GetNumberGroups(numberToConvert);
            System.Text.StringBuilder overAllText = new System.Text.StringBuilder();
            
            foreach (int groupNumber in numberGroups)
            {
                if (groupNumber > 0)
                {
                    string groupText = GetTextForNumberGroup(groupNumber);
                    overAllText.Append(groupText);
                }                
            }

            return overAllText.ToString();
        }

        /// <summary>
        /// Create 4 groups from input
        /// </summary>      
        public static int[] GetNumberGroups(int numberToConvert)
        {
            int[] numberGroups = new int[4];

            for (int i = 0; i < 4; i++)
            {
                numberGroups[i] = numberToConvert % 1000;
                numberToConvert = numberToConvert / 1000;
            }

            return numberGroups;
        }
        
        /// <summary>
        /// break this number into hundreds and tens and units
        /// </summary> 
        public static string GetTextForNumberGroup(int groupNumber)
        {  
            System.Text.StringBuilder groupText = new System.Text.StringBuilder();

            string hundredText = GetHundreds(groupNumber);

            // did we get a hundred number
            if (!string.IsNullOrEmpty(hundredText))
            {
                string hundredAnd = $"{hundredText}";
                groupText.Append(hundredAnd);
            }

            // get remainder
            int oneTo19Number = groupNumber % 100;

            // have we got any zero to 19
            if (!string.IsNullOrEmpty(hundredText) && oneTo19Number != 0)
            {
                string addAnd = $" {AND} ";
                groupText.Append(addAnd);
            }

            if (oneTo19Number > 0)
            {
                string remainderText = GetRemainderText(oneTo19Number);

                groupText.Append(remainderText);
            }
            

            return groupText.ToString();
        }

        #endregion

        #region Private Methods
        private static string GetHundreds(int groupNumber)
        {
            string result = string.Empty;

            int hundred = groupNumber / 100;           

            // is there a hundred
            if (hundred != 0)
            {
                result = $"{zeroTo19[hundred]} {twentyTo100[8]}";
            }

            return result;
        }

        private static string GetRemainderText(int oneTo19Number)
        {
            string result = string.Empty;

            int tensUnit = oneTo19Number / 10;
            int singleUnit = oneTo19Number % 10;

            if (tensUnit >= 2)
            {
                result = twentyTo100[tensUnit-2];
                if (singleUnit != 0)
                    result = $"{result} {zeroTo19[singleUnit]}";
            }
            else
            {
                result = zeroTo19[oneTo19Number];
            }
            return result;
        }

        #endregion
    }
}
